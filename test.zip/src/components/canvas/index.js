
import BallCanvas from "./Ball";
import ComputersCanvas from "./Computers";

export { BallCanvas, ComputersCanvas};
