import React, { Suspense } from "react";
import { Canvas } from "@react-three/fiber";
import { OrbitControls, Preload, useGLTF } from "@react-three/drei";
import CanvasLoader from "../Loader";  // Ensure this path is correct

const isHighEndDevice = () => {
  const hardwareConcurrency = navigator.hardwareConcurrency || 4;
  const pixelCount = window.screen.width * window.screen.height;
  return hardwareConcurrency >= 8 && pixelCount > 2073600;
};

const deviceType = isHighEndDevice() ? 'high-end' : 'low-end';

const Computers = ({ deviceType }) => {
  const { scene } = useGLTF("./dv_meterr/compressed.glb");  // Using only one model now

  return (
    <mesh>
      <hemisphereLight intensity={0.1} groundColor='black' />
      <spotLight
        position={[-20, 50, 10]}
        angle={0.12}
        penumbra={1}
        intensity={deviceType === 'high-end' ? 1 : 0.8}
        castShadow
        shadow-mapSize={deviceType === 'high-end' ? 1024 : 512}
      />
      {deviceType === 'high-end' && <pointLight intensity={1} />}
      <primitive
        object={scene}
        scale={15}
        position={[0, -2, 0]}
        rotation={[0, 1.1, 0]}
      />
    </mesh>
  );
};

const ComputersCanvas = () => {
  return (
    <Canvas
      frameloop='demand'
      shadows
      dpr={deviceType === 'high-end' ? [1, 2] : [0.5, 1.5]}
      camera={{ position: [20, 3, 5], fov: 25 }}
      gl={{ preserveDrawingBuffer: true }}
    >
      <Suspense fallback={<CanvasLoader />}>
        <OrbitControls
          autoRotate
          enableZoom={false}
          maxPolarAngle={Math.PI / 2}
          minPolarAngle={Math.PI / 2}
        />
        <Computers deviceType={deviceType} />
      </Suspense>

      <Preload all />
    </Canvas>
  );
};

export default ComputersCanvas;
